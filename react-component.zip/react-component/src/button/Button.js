//module = component = object
import React from 'react'
import './Button.css'

class Button extends React.Component{
    constructor(props){
        super(props);
        this.text = this.props.text;
        this.state = {
            disabled: this.props.disabled
        }
    }
    render(){
        let styles = {}
        if (this.props.type =="danger"){
         styles = {
            backgroundColor: "red"
        }
        }
        //return JSX syntax
        return <button className="my-button" style={styles} disabled={this.state.disabled}>{this.text}</button> //{this.props.text} -  a facut sa se evidentieze diferenta dintre butoane
    }
}
export default Button