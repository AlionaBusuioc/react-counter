import React from 'react';
import './App.css';
import Button from './button/Button'
import CountButton from './button/CountButton';

function App() {
  return (
    <div className="App">
      <header className="App-header">
        <Button text="OK" type="danger"/>
        <Button text="More than OK"/>
        <Button text="Not OK" disabled={true}/>
        <hr/>
         <CountButton text="please wait ...." delay="10" disabled={true}/>
      </header>
    </div>
  );
}

export default App;
